Add car-1.jpg through car-9.jpg here. The live Hatchable project already contains these assets.

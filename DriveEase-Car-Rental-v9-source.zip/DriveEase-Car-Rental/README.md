# DriveEase Car Rental

Current source snapshot of the DriveEase Hatchable project (v9).

## Open in VS Code

1. Extract this ZIP.
2. Open the `DriveEase-Car-Rental` folder in VS Code.
3. The project structure is:
   - `public/` — frontend pages and styles
   - `api/` — booking/availability APIs
   - `migrations/` — PostgreSQL schema
   - `seed.sql` — starter fleet
   - `hatchable.toml` — authentication/database access configuration

## Important

The nine car JPEG binaries are not included in this source-only export because Hatchable's project-file connector does not expose a binary download/export operation in this environment.

The frontend expects:
`public/cars/car-1.jpg` through `public/cars/car-9.jpg`

The live Hatchable project already contains those nine images. You can export/copy them from the Hatchable project when you have access to the console.

## Current functionality

- Fleet search and category/price filters
- Car details
- Email-code authentication
- Passkey-ready login
- Live availability checking
- Booking creation
- Rental price calculation
- My Bookings
- Booking cancellation API
- Booking confirmation page
- Local car-image mapping by car ID

## Next attractive upgrades

- Premium animated hero
- Better car gallery and image carousel
- Sticky booking summary
- Modern customer dashboard
- Reviews and ratings
- Location/map picker
- Payment checkout UI
- Coupons/discounts
- Admin fleet management
- Responsive mobile navigation
- Dark mode

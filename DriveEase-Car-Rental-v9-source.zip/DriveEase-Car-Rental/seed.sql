INSERT INTO cars
(name, brand, category, seats, transmission, fuel, price_per_day, image_url, description, featured)
SELECT 'City Cruiser','Toyota','Economy',5,'Automatic','Petrol',42.00,
'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?auto=format&fit=crop&w=1200&q=80',
'Comfortable, efficient and easy to drive around the city.',true
WHERE NOT EXISTS (SELECT 1 FROM cars WHERE name='City Cruiser');

INSERT INTO cars
(name, brand, category, seats, transmission, fuel, price_per_day, image_url, description, featured)
SELECT 'Executive Sedan','BMW','Premium',5,'Automatic','Petrol',89.00,
'https://images.unsplash.com/photo-1555215695-3004980ad54e?auto=format&fit=crop&w=1200&q=80',
'A refined sedan for business trips, airport runs and special occasions.',true
WHERE NOT EXISTS (SELECT 1 FROM cars WHERE name='Executive Sedan');

INSERT INTO cars
(name, brand, category, seats, transmission, fuel, price_per_day, image_url, description, featured)
SELECT 'Adventure SUV','Jeep','SUV',7,'Automatic','Diesel',76.00,
'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=1200&q=80',
'Spacious seven-seat SUV built for longer journeys and weekend escapes.',true
WHERE NOT EXISTS (SELECT 1 FROM cars WHERE name='Adventure SUV');

INSERT INTO cars
(name, brand, category, seats, transmission, fuel, price_per_day, image_url, description, featured)
SELECT 'Urban Hatch','Volkswagen','Compact',5,'Manual','Petrol',49.00,
'https://images.unsplash.com/photo-1502877338535-766e1452684a?auto=format&fit=crop&w=1200&q=80',
'A practical compact car with a clean interior and low running cost.',false
WHERE NOT EXISTS (SELECT 1 FROM cars WHERE name='Urban Hatch');

INSERT INTO cars
(name, brand, category, seats, transmission, fuel, price_per_day, image_url, description, featured)
SELECT 'Luxury Grand Tourer','Mercedes-Benz','Luxury',5,'Automatic','Petrol',119.00,
'https://images.unsplash.com/photo-1563720223185-11003d516935?auto=format&fit=crop&w=1200&q=80',
'Premium comfort, quiet cruising and a polished cabin for long-distance travel.',true
WHERE NOT EXISTS (SELECT 1 FROM cars WHERE name='Luxury Grand Tourer');

INSERT INTO cars
(name, brand, category, seats, transmission, fuel, price_per_day, image_url, description, featured)
SELECT 'Family Explorer','Kia','SUV',7,'Automatic','Petrol',68.00,
'https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?auto=format&fit=crop&w=1200&q=80',
'Flexible seven-seat space with room for luggage, family trips and weekend getaways.',false
WHERE NOT EXISTS (SELECT 1 FROM cars WHERE name='Family Explorer');

INSERT INTO cars
(name, brand, category, seats, transmission, fuel, price_per_day, image_url, description, featured)
SELECT 'Sport Coupe','Audi','Premium',4,'Automatic','Petrol',105.00,
'https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?auto=format&fit=crop&w=1200&q=80',
'Sharp handling and premium comfort for drivers who want something more exciting.',false
WHERE NOT EXISTS (SELECT 1 FROM cars WHERE name='Sport Coupe');

INSERT INTO cars
(name, brand, category, seats, transmission, fuel, price_per_day, image_url, description, featured)
SELECT 'Eco Hybrid','Toyota','Hybrid',5,'Automatic','Hybrid',59.00,
'https://images.unsplash.com/photo-1550355291-bbee04a92027?auto=format&fit=crop&w=1200&q=80',
'Fuel-efficient hybrid driving for comfortable everyday journeys with lower running costs.',false
WHERE NOT EXISTS (SELECT 1 FROM cars WHERE name='Eco Hybrid');

INSERT INTO cars
(name, brand, category, seats, transmission, fuel, price_per_day, image_url, description, featured)
SELECT 'Executive SUV','Volvo','Luxury',5,'Automatic','Hybrid',112.00,
'https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?auto=format&fit=crop&w=1200&q=80',
'Refined SUV comfort with a spacious cabin and confident road presence.',false
WHERE NOT EXISTS (SELECT 1 FROM cars WHERE name='Executive SUV');
